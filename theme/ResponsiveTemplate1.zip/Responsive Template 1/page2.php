<?php include 'includes/header.php'; 
?>
<div class="container">
	<div class="row">
		<div class="col-md-9 col-sm-9 left">
			<div class="page-header jumbotron">
				<div class="container">
					<h1><span>Image Title</span><br><span>840 x 275</span></h1>
				</div>
			</div>
			<h1>Page 2</h1>
			<p>Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id.</p>
			<p>Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id.</p>
			<p>Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id.</p>
		</div>
		<div class="col-md-3 col-sm-3 right" id="sidebar1">
			<h3>Latest Posts</h3>
			<div class="well">
				<ul class="nav nav-stacked">
					<li><a href="#">Blog Post 1</a></li>
					<li><a href="#">Blog Post 2</a></li>
					<li><a href="#">Blog Post 3</a></li>
					<li><a href="#">Blog Post 4</a></li>
				</ul>
			</div>
			<h3>Newsletter Sign-Up!</h3>
			<div class="newsletter well">
				<p>Subscribe to our newsletter for good news, sent out every month.</p>
				<span>We promise to only send you good things!</span>
				<div class="newsletter-form-group">
					<!-- <label>Email Address:</label> -->
					<input type="email" class="form-control" id="email" placeholder="Email Address">					<button class="btn-newsletter icon-arrow-right-newsletter">Submit</button>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include 'includes/footer.php'; 
?>