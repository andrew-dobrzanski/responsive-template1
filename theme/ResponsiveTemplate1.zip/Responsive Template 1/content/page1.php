<?php include '../includes/header.php'; 

?>

<div class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12">
			<div class="page-header jumbotron">
				<div class="container">
					<h1><span>Image Title</span><br><span>1140 x 275</span></h1>
				</div>
			</div>
			<h1>Page 1</h1>
			<p>Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id.</p>
			
			<p>Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id.</p>
			
			<p>Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id. Sumo nobis efficiendi eu duo, ad vix sint habeo suscipiantur. Lorem ipsum dolor sit amet, mea labitur percipit rationibus id.</p>
		</div>
	</div>
</div>

<?php include '../includes/footer.php'; 

?>